package vpomodel.rest;


import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import oracle.jbo.ApplicationModule;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.client.Configuration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


@Path("countryrepository")
@Consumes("application/json")
@Produces("application/json")
public class CountryRestServices {
    private static final String amDef = "vpomodel.eo.AppModule";
    private static final String config = "AppModuleLocal";


    public CountryRestServices() {
        super();
    }


    @GET
    @Path("/countryLov")
    public String getCountryDataLOV() {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        ApplicationModule am = null;
        try {
            am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("CountryLOV1");
                vo.executeQuery();

                int j = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        int regionId = Integer.parseInt(row.getAttribute("RegionId").toString());
                        String region = (String) row.getAttribute("Region");
                        String countryIdDelimit = (String) row.getAttribute("CountryId");
                        String countryDelimit = (String) row.getAttribute("Country");


                        JSONArray jsonCountryArray = new JSONArray();
                        JSONObject jsonObjectR2 = new JSONObject();

                        if (countryIdDelimit != null && countryIdDelimit.contains(",")) {
                            String[] countryData = countryDelimit.split(",");
                            String[] countryIdData = countryIdDelimit.split(",");
                            int i = 0;
                            for (int pos = 0; pos < countryIdData.length; pos++) {
                                JSONObject jsonObjectR3 = new JSONObject();
                                jsonObjectR3.put("countryName", countryData[pos]);
                                jsonObjectR3.put("CountryID", countryIdData[pos]);
                                jsonCountryArray.put(i, jsonObjectR3);
                                i++;
                            }
                        } else {
                            JSONObject jsonObjectR3 = new JSONObject();
                            jsonObjectR3.put("countryName", countryDelimit);
                            jsonObjectR3.put("CountryID", countryIdDelimit);
                            jsonCountryArray.put(0, jsonObjectR3);
                        }
                        jsonObjectR2.put("Region", region);
                        jsonObjectR2.put("RegionId", regionId);
                        jsonObjectR2.put("Country", jsonCountryArray);
                        jsonCountryArrayR2.put(j, jsonObjectR2);
                        j++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                try {
                    jsonObjectR.put("countries", jsonCountryArrayR2);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }


                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        } finally {
            if (am != null)
                Configuration.releaseRootApplicationModule(am, true);
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/countryDetails")
    public String getCountryDetails(@QueryParam("regionIdValue") String regionid,
                                    @QueryParam("countryIdValue") String countryId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("countryDetailsMO1_1");
                vo.setNamedWhereClauseParam("region_id_m3", regionid);
                vo.setNamedWhereClauseParam("country_id_m3", countryId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("regionCountryId", row.getAttribute("RegionCountryId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("regionCountryId", "");
                        }
                        try {
                            jsonObjectR3.put("regionId", row.getAttribute("RegionId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("regionId", "");
                        }

                        try {
                            jsonObjectR3.put("region", row.getAttribute("Region").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("region", "");
                        }
                        try {
                            jsonObjectR3.put("countryId", row.getAttribute("CountryId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("countryId", "");
                        }
                        try {
                            jsonObjectR3.put("country", row.getAttribute("Country").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("country", "");
                        }
                        try {
                            jsonObjectR3.put("countryContact", row.getAttribute("CountryContact").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("countryContact", "");
                        }
                        try {
                            jsonObjectR3.put("countryPhoneCode", row.getAttribute("CountryPhoneCode").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("countryPhoneCode", "");
                        }
                        try {
                            jsonObjectR3.put("officeWorkingDays", row.getAttribute("OfficeWorkingDays").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("officeWorkingDays", "");
                        }
                        try {
                            jsonObjectR3.put("holidayClosure", row.getAttribute("HolidayClosure").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("holidayClosure", "");
                        }
                        try {
                            jsonObjectR3.put("timezone", row.getAttribute("Timezone").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("timezone", "");
                        }
                        try {
                            jsonObjectR3.put("updatedBy", row.getAttribute("UpdatedBy").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("updatedBy", "");
                        }

                        try {
                            jsonObjectR3.put("updatedDate", row.getAttribute("UpdatedDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("updatedDate", "");
                        }
                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("countryDetails", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/phaseDetails")
    public String getPhaseDetails(@QueryParam("countryIdVal") String countryVal,
                                  @QueryParam("regionIdVal") String regionVal) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {

                ViewObject vo = am.findViewObject("PhaseDetails1");
                vo.setNamedWhereClauseParam("phaseCountryId", countryVal);
                vo.setNamedWhereClauseParam("phaseRegionId", regionVal);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("regionId", row.getAttribute("RegionId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("regionId", "");
                        }
                        try {
                            jsonObjectR3.put("region", row.getAttribute("Region").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("region", "");
                        }
                        try {
                            jsonObjectR3.put("countryId", row.getAttribute("CountryId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("countryId", "");
                        }
                        try {
                            jsonObjectR3.put("country", row.getAttribute("Country").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("country", "");
                        }

                        try {
                            jsonObjectR3.put("regionCountryId", row.getAttribute("RegionCountryMappingId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("regionCountryId", "");
                        }
                        try {
                            jsonObjectR3.put("questionid", row.getAttribute("QuestionId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("questionid", "");
                        }
                        try {
                            jsonObjectR3.put("questionDetails", (String) row.getAttribute("QuestionDetails"));
                        } catch (Exception e) {
                            jsonObjectR3.put("questionDetails", "");
                        }
                        try {
                            jsonObjectR3.put("questionCategory", (String) row.getAttribute("QuestionCategory"));
                        } catch (Exception e) {
                            jsonObjectR3.put("questionCategory", "");
                        }
                        try {
                            jsonObjectR3.put("haEcSubmission", row.getAttribute("HaEcSubmission").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("haEcSubmission", "");
                        }
                        try {
                            jsonObjectR3.put("ris", row.getAttribute("Ris").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("ris", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("phaseDetails", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/subCategoryDetails")
    public String getSubCategoryDetails() {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {

                ViewObject vo = am.findViewObject("CategoryLOV1");
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("subCategoryName", (String) row.getAttribute("QuestionCategory"));
                        } catch (Exception e) {
                            jsonObjectR3.put("subCategoryName", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("subCategoryDetails", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/vendorDetails")
    public String getVendorDetails() {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {

                ViewObject vo = am.findViewObject("vendorLOV1");
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("vendorName", row.getAttribute("Vendorcategoryname").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorName", "");
                        }
                        try {
                            jsonObjectR3.put("vendorId", row.getAttribute("Vendorcategoryid").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("vendorId", "");
                        }
                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("vendorDetails", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();

            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();

    }


    @GET
    @Path("/gridDetails")
    public String getGridDetails(@QueryParam("countryIdVal") String countryVal,
                                 @QueryParam("regionIdVal") String regionVal,
                                 @QueryParam("phaseNameVal") String phaseName) {

        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {

                ViewObject vo = am.findViewObject("PWCLQuery1");
                vo.setNamedWhereClauseParam("pwchlquerycountryid", countryVal);
                vo.setNamedWhereClauseParam("pwchlqueryregionid", regionVal);
                vo.setNamedWhereClauseParam("pwchlqueryphasename", phaseName);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();


                        try {
                            jsonObjectR3.put("regionCountryId", row.getAttribute("RegionCountryMappingId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("regionCountryId", "");
                        }
                        try {
                            jsonObjectR3.put("regionId", row.getAttribute("RegionId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("regionId", "");
                        }
                        try {
                            jsonObjectR3.put("region", row.getAttribute("Region").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("region", "");
                        }
                        try {
                            jsonObjectR3.put("countryId", row.getAttribute("CountryId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("countryId", "");
                        }
                        try {
                            jsonObjectR3.put("country", row.getAttribute("Country").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("country", "");
                        }
                        try {
                            jsonObjectR3.put("phasewiseQuestionId", row.getAttribute("PhasewiseQuestionId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("phasewiseQuestionId", "");
                        }
                        try {
                            jsonObjectR3.put("questionId", row.getAttribute("QuestionId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("questionId", "");
                        }
                        try {
                            jsonObjectR3.put("questionCategory", row.getAttribute("QuestionCategory").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("questionCategory", "");
                        }
                        try {
                            jsonObjectR3.put("questionDetails", row.getAttribute("QuestionDetails").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("questionDetails", "");
                        }
                        try {
                            jsonObjectR3.put("phaseName", row.getAttribute("PhaseName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("phaseName", "");
                        }
                        try {
                            jsonObjectR3.put("comments", row.getAttribute("Comments").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("comments", "");
                        }


                        ViewObject vo1 = am.findViewObject("PWCLVendorQuery1");
                        vo1.setNamedWhereClauseParam("pwclvendorqueryquesid",
                                                     row.getAttribute("PhasewiseQuestionId").toString());
                        vo1.executeQuery();
                        boolean hasVendors = false;
                        String vendorList = "";
                        while (vo1.hasNext()) {
                            try {
                                Row row1 = vo1.next();
                                hasVendors = true;
                                JSONObject jsonsubObject1 = new JSONObject();
                                try {
                                    jsonsubObject1.put("option", row1.getAttribute("ChklistFlag").toString());
                                } catch (Exception e) {
                                    jsonsubObject1.put("option", "");
                                }
                                try {
                                    vendorList = vendorList + "-" + row1.getAttribute("VendorCategoryId").toString();
                                    jsonsubObject1.put("vendorCategoryId",
                                                       row1.getAttribute("VendorCategoryId").toString());
                                } catch (Exception e) {
                                    jsonsubObject1.put("vendorCategoryId", "");
                                }
                                try {
                                    jsonsubObject1.put("vendorCategoryName",
                                                       row1.getAttribute("VendorCategoryName").toString());
                                } catch (Exception e) {
                                    jsonsubObject1.put("vendorCategoryName", "");
                                }
                                try {
                                    jsonsubObject1.put("phaseWiseQuestionId",
                                                       row1.getAttribute("PhasewiseQuestionId").toString());
                                } catch (Exception e) {
                                    jsonsubObject1.put("phaseWiseQuestionId", "");
                                }

                                jsonObjectR3.put(row1.getAttribute("VendorCategoryId").toString(), jsonsubObject1);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (hasVendors) {
                            ViewObject checkVendors = am.findViewObject("vendorLOV1");
                            checkVendors.executeQuery();
                            while (checkVendors.hasNext()) {
                                try {
                                    Row checkVendorsRows = checkVendors.next();
                                    JSONObject checkVendorJO = new JSONObject();

                                    if (vendorList != null) {
                                        if (!vendorList.contains(checkVendorsRows.getAttribute("Vendorcategoryid")
                                                                 .toString())) {
                                            try {
                                                checkVendorJO.put("vendorCategoryId",
                                                                  checkVendorsRows.getAttribute("Vendorcategoryid")
                                                                  .toString());
                                            } catch (Exception e) {
                                                checkVendorJO.put("vendorCategoryId", "");
                                            }
                                            try {
                                                checkVendorJO.put("vendorCategoryName",
                                                                  checkVendorsRows.getAttribute("Vendorcategoryname")
                                                                  .toString());
                                            } catch (Exception e) {
                                                checkVendorJO.put("vendorCategoryName", "");
                                            }

                                            checkVendorJO.put("phaseWiseQuestionId", "");
                                            checkVendorJO.put("option", "");
                                            jsonObjectR3.put(checkVendorsRows.getAttribute("Vendorcategoryid")
                                                             .toString(), checkVendorJO);
                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                            jsonObjectR3.put("editable", "false");
                        } else {
                            ViewObject noVendors = am.findViewObject("vendorLOV1");
                            noVendors.executeQuery();

                            while (noVendors.hasNext()) {
                                try {
                                    Row noVendorsRows = noVendors.next();
                                    JSONObject noVendorJO = new JSONObject();

                                    noVendorJO.put("option", "");

                                    try {
                                        noVendorJO.put("vendorCategoryId",
                                                       noVendorsRows.getAttribute("Vendorcategoryid").toString());
                                    } catch (Exception e) {
                                        noVendorJO.put("vendorCategoryId", "");
                                    }
                                    try {
                                        noVendorJO.put("vendorCategoryName",
                                                       noVendorsRows.getAttribute("Vendorcategoryname").toString());
                                    } catch (Exception e) {
                                        noVendorJO.put("vendorCategoryName", "");
                                    }

                                    noVendorJO.put("phaseWiseQuestionId", "");

                                    jsonObjectR3.put(noVendorsRows.getAttribute("Vendorcategoryid").toString(),
                                                     noVendorJO);

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                            jsonObjectR3.put("editable", "true");
                        }


                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                try {
                    jsonObjectR.put("gridDetails", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            }
        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }

}
