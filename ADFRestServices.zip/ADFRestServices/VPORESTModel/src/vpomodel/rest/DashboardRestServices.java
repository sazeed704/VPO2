package vpomodel.rest;

import java.util.HashMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import oracle.jbo.ApplicationModule;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;
import oracle.jbo.client.Configuration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import vpomodel.eo.AppModuleImpl;


@Path("dashboard")
@Consumes("application/json")
@Produces("application/json")
public class DashboardRestServices {

    private static final String amDef = "vpomodel.eo.AppModule";
    private static final String config = "AppModuleLocal";

    public DashboardRestServices() {
        super();
    }


    @GET
    @Path("/dashboardCounts")
    public String getDashboardHeaderDetails(@QueryParam("personnelIdVal") String personnelId) {
        JSONObject jsonObjectR;
        HashMap<String, String> dashboardCounts = new HashMap<String, String>();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);

            try {
                AppModuleImpl service = (AppModuleImpl) am;
                dashboardCounts = service.callDashboardProcedure(personnelId);
                // dashboardCounts.forEach((k, v) -> System.out.println(k + " : " + v));
                jsonObjectR = new JSONObject(dashboardCounts);
                service.remove();
                Configuration.releaseRootApplicationModule(am, true);
            } catch (Exception e) {
                e.printStackTrace();
                jsonObjectR = new JSONObject();
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
            }

        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/trialsSummary")
    public String getDashboardTrailsSummary(@QueryParam("personnelIdVal") String personnelId,
                                            @QueryParam("regionIdVal") String regionId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("TrialsSummaryChange1");
                vo.setNamedWhereClauseParam("chPId", personnelId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("trialCode", row.getAttribute("StudyCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("trialCode", "");
                        }
                        try {
                            jsonObjectR3.put("siteId", row.getAttribute("StudySiteId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("siteId", "");
                        }
                        try {
                            jsonObjectR3.put("primaryInvestigator", row.getAttribute("InvestigatorName").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("primaryInvestigator", "");
                        }
                        try {
                            jsonObjectR3.put("pendingForms", row.getAttribute("PendingForms").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("pendingForms", "");
                        }
                        try {
                            jsonObjectR3.put("pendingShipment", row.getAttribute("PendingShipment").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("pendingShipment", "");
                        }
                        try {
                            jsonObjectR3.put("totalAction", row.getAttribute("TotalAction").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("totalAction", "");
                        }
                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("trialsSummary", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
            }

        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/alertsSummary")
    public String getDashboardAlertsSummary(@QueryParam("personnelIdVal") String personnelId) {
        JSONObject jsonObjectR = new JSONObject();
        JSONArray jsonCountryArrayR2 = new JSONArray();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("AlertSummaryVO1");
                vo.setNamedWhereClauseParam("alerts_personnelId", personnelId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        JSONObject jsonObjectR3 = new JSONObject();
                        try {
                            jsonObjectR3.put("trialCode", row.getAttribute("StudyCodeAlias").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("trialCode", "");
                        }
                        try {
                            jsonObjectR3.put("siteId", row.getAttribute("StudySiteId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("siteId", "");
                        }
                        try {
                            jsonObjectR3.put("category", row.getAttribute("AlertCategory").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("category", "");
                        }
                        try {
                            jsonObjectR3.put("title", row.getAttribute("AlertDetails").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("title", "");
                        }
                        try {
                            jsonObjectR3.put("date", row.getAttribute("CreatedDate").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("date", "");
                        }
                        try {
                            jsonObjectR3.put("readFlag", row.getAttribute("ReadFlag").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("readFlag", "");
                        }
                        try {
                            jsonObjectR3.put("archiveFlag", row.getAttribute("ArchiveFlag").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("archiveFlag", "");
                        }
                        try {
                            jsonObjectR3.put("userAlertDtlId", row.getAttribute("UserAlertDtlId").toString());
                        } catch (Exception e) {
                            jsonObjectR3.put("userAlertDtlId", "");
                        }

                        jsonCountryArrayR2.put(i, jsonObjectR3);
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    jsonObjectR.put("alertsSummary", jsonCountryArrayR2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                e.printStackTrace();
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
            }

        } catch (Exception e) {
            jsonObjectR = new JSONObject();
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }


    @GET
    @Path("/alertsCount")
    public String getAlertsUnreadCount(@QueryParam("personnelIdVal") String personnelId) {
        JSONObject jsonObjectR = new JSONObject();
        try {
            ApplicationModule am = Configuration.createRootApplicationModule(amDef, config);
            try {
                ViewObject vo = am.findViewObject("AlertsUnreadCount1");
                vo.setNamedWhereClauseParam("unalerts_personnelId", personnelId);
                vo.executeQuery();

                int i = 0;
                while (vo.hasNext()) {
                    try {
                        Row row = vo.next();
                        try {
                            jsonObjectR.put(row.getAttribute("Unreadcount").toString(),
                                            row.getAttribute("Selectobjects1").toString());
                        } catch (Exception e) {
                            jsonObjectR.put("UnreadCount", "");
                        }
                        i++;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                Configuration.releaseRootApplicationModule(am, true);
                return jsonObjectR.toString();
            } catch (Exception e) {
                try {
                    jsonObjectR.put("ERRORMSG", "SQL Error. Contact your ADF team.");
                } catch (JSONException f) {
                    f.printStackTrace();
                }
                Configuration.releaseRootApplicationModule(am, true);
            }

        } catch (Exception e) {
            try {
                jsonObjectR.put("ERRORMSG", "Not able to connect to Server");
            } catch (JSONException f) {
                f.printStackTrace();
            }
        }
        return jsonObjectR.toString();
    }

}
